const t=extend(GenericCrafter,"yzjsq8-1",{});
const drawer=new DrawAnimation();
drawer.frameCount=150;
drawer.sine=false;
t.drawer=drawer;